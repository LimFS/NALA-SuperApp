import { createApp } from 'vue'
import './index.css'
import App from './ui/App.vue'

createApp(App).mount('#app')
