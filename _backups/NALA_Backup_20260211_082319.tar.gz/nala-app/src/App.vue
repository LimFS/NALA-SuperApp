<template>
  <router-view></router-view>
</template>

<style>
/* Global Styles if needed */
</style>
