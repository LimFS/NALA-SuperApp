const express = require('express');
const crypto = require('crypto');
const cors = require('cors');
// const db = require('./db'); // PG Disabled
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'nala-super-secret-key-2026';

// --- DATABASE (SQLite) ---
const dbPath = path.resolve(__dirname, 'nala.db');
const db = new sqlite3.Database(dbPath);

// Init DB
db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS users (
        user_id TEXT PRIMARY KEY,
        first_name TEXT,
        last_name TEXT,
        email TEXT UNIQUE,
        password_hash TEXT,
        role TEXT,
        profile_icon TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Seed Data
    const seed = async () => {
        const hash = await bcrypt.hash('password123', 10);
        const users = [
            ['uuid-del', 'Del', 'Spooner', 'student@nala.ai', hash, 'student', '/assets/profiles/del_durian.png'],
            ['uuid-hal', 'Hal', '9000', 'faculty@nala.ai', hash, 'faculty', '/assets/profiles/hal_9000.png']
        ];

        users.forEach(u => {
            db.run(`INSERT OR IGNORE INTO users (user_id, first_name, last_name, email, password_hash, role, profile_icon) VALUES (?, ?, ?, ?, ?, ?, ?)`, u);
        });
    };
    seed();
});

app.use(cors());
app.use(express.json());

// --- AUTH MIDDLEWARE ---
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    if (!token) return res.sendStatus(401);

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

// --- ROUTES ---

// Health Check
app.get('/health', (req, res) => {
    res.json({ status: 'ok', service: 'nala-user-service', db: 'sqlite' });
});

// Login
app.post('/api/auth/login', (req, res) => {
    const { email, password } = req.body;
    db.get("SELECT * FROM users WHERE email = ?", [email], async (err, user) => {
        if (err) return res.status(500).json({ error: "DB Error" });
        if (!user) return res.status(401).json({ error: "Invalid credentials" });

        const match = await bcrypt.compare(password, user.password_hash);
        if (match) {
            const token = jwt.sign({ id: user.user_id, role: user.role }, JWT_SECRET, { expiresIn: '1h' });
            res.json({
                token,
                user: {
                    user_id: user.user_id,
                    first_name: user.first_name,
                    last_name: user.last_name,
                    email: user.email,
                    role: user.role,
                    profile_icon: user.profile_icon
                }
            });
        } else {
            res.status(401).json({ error: "Invalid credentials" });
        }
    });
});

// --- SHARED SECRET (Must match Agent) ---
const SHARED_SECRET = crypto.scryptSync('nala-agent-shared-secret-2025', 'salt', 32);
const IV_LENGTH = 16;

const encryptToken = (text) => {
    const iv = crypto.randomBytes(IV_LENGTH);
    const cipher = crypto.createCipheriv('aes-256-cbc', SHARED_SECRET, iv);
    let encrypted = cipher.update(text);
    encrypted = Buffer.concat([encrypted, cipher.final()]);
    return iv.toString('hex') + ':' + encrypted.toString('hex');
};

// Issue Encrypted Handover Token
app.post('/api/auth/issue-token', authenticateToken, (req, res) => {
    // 1. Construct Payload
    const payload = JSON.stringify({
        email: req.user.id, // In NALA DB, user_id is the primary key? No, email is unique, user_id is UUID.
        // Wait, req.user from JWT might be { id, role }. We need Email. 
        // JWT creation: jwt.sign({ id: user.user_id, role: user.role }...)
        // We need to fetch the email or trust the client? 
        // Better: Fetch User to be sure, OR if JWT contained email.
        // Let's fetch the user to be safe and get the Name too.
        timestamp: Date.now()
    });

    db.get("SELECT email, first_name, role FROM users WHERE user_id = ?", [req.user.id], (err, user) => {
        if (err || !user) return res.status(500).json({ error: "User Retrieval Failed" });

        const data = JSON.stringify({
            email: user.email,
            role: user.role,
            name: user.first_name,
            timestamp: Date.now()
        });

        const token = encryptToken(data);
        res.json({ token });
    });
});

app.get('/api/user/me', authenticateToken, (req, res) => {
    db.get("SELECT user_id, first_name, last_name, email, role, profile_icon FROM users WHERE user_id = ?", [req.user.id], (err, row) => {
        if (err) return res.sendStatus(500);
        res.json(row);
    });
});

app.listen(PORT, () => {
    console.log(`[UserId Service] Running on Port ${PORT} (SQLite Mode)`);
});
