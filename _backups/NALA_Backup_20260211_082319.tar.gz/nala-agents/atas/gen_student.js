import { encryptDeterministic } from './src/utils/crypto.js';
console.log(encryptDeterministic('student@nala.ai'));
